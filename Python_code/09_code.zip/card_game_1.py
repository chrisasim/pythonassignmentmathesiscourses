# card_game.py (in Python v3.5)

from playing_cards import *

def computer_plays():
    global d, table, computer_hand, what_happened
    target_val=table[-1].value
    target_sym=table[-1].symbol
    while True:
        for c in computer_hand:
            if c.value==target_val or c.symbol==target_sym:
                print("Ο Η/Υ ρίχνει",c)
                computer_hand.remove(c)
                table.append(c)
                what_happened="computer_played"
                return
        new_card=d.draw()
        if new_card=="empty":
            what_happened="deck_finished"
            return
        else:
            print("Ο Η/Υ τραβάει φύλλο.")
            computer_hand.append(new_card)

def print_info():
    global d, table, computer_hand, human_hand
    print()
    print("Η τράπουλα έχει", len(d.content), "φύλλα")
    print("Ο Η/Υ έχει", len(computer_hand), "φύλλα")
    print("Στο τραπέζι έχουν πέσει", len(table), "φύλλα")
    print("Το πάνω φύλλο είναι",table[-1])
    print("Τα φύλλα σου είναι",len(human_hand))
    HHS=[str(x) for x in human_hand]
    print(HHS)
    print()
    print("Διάλεξε ποιό θα πετάξεις")
    print("ή πάτα σκέτο ENTER για να τραβήξεις")

def human_plays():
    global d, table, human_hand, what_happened
    while True:
        print_info()
        sel=input()
        if sel=="":
            new_card=d.draw()
            if new_card=="empty":
                what_happened="deck_finished"
                return
            else:
                human_hand.append(new_card)
        else:
            HHS=[str(x) for x in human_hand]
            if not(sel in HHS):
                print(sel, "???   Δεν έχεις τέτοιο φύλλο.")
            else:
                t=table[-1]
                target_val=t.value
                target_sym=t.symbol
                if sel[0]!=target_val and sel[1]!=target_sym:
                    print("Δεν επιτρέπεται να ρίξεις το φύλλο ",sel)
                else:
                    print("Ρίχνεις το",sel)
                    ind=HHS.index(sel)
                    selc=human_hand[ind]
                    human_hand.remove(selc)
                    table.append(selc)
                    what_happened="human_played"
                    return

def initial():
    global d, table, computer_hand, human_hand, what_happened
    print("Μαζεύω τα χαρτιά...")
    d.collect()
    table=[]
    computer_hand=[]
    human_hand=[]
    print("Ανακατεύω την τράπουλα...")
    d.shuffle()
    print("Μοιράζω τα φύλλα...")
    table.append(d.draw())
    print("Στο τραπέζι έπεσε",table[-1])
    for i in range(7):
        human_hand.append(d.draw())
        computer_hand.append(d.draw())
    print("Στρίβω ένα νόμισμα...", end=" ")
    if random.random()<0.5:
        print("...Παίζεις πρώτος")
        what_happened="computer_played"
    else:
        print("...Ο Η/Υ παιζει πρώτος")
        what_happened="human_played"

def evaluate():
    global computer_hand, human_hand, what_happened
    if what_happened=="human_wins": print("ΣΥΓΧΑΡΗΤΗΡΙΑ. ΚΕΡΔΙΣΕΣ!!!")
    if what_happened=="computer_wins": print("Ο Η/Υ ΚΕΡΔΙΣΕ.")
    if what_happened=="deck_finished":
        ch=len(computer_hand)
        hh=len(human_hand)
        print("Η τράπουλα τελείωσε, ο Η/Υ έχει",ch, "φύλλα και ο παίκτης", hh)
        if ch>hh: print("ΣΥΓΧΑΡΗΤΗΡΙΑ. ΚΕΡΔΙΣΕΣ!!!")
        if ch<hh: print("Ο Η/Υ ΚΕΡΔΙΣΕ.")
        if ch==hh: print("ΙΣΟΠΑΛΙΑ!!!")
    print()

def next_turn():
    global what_happened
    while True:
        if what_happened=="game_start":
            initial()
        elif what_happened=="human_played":
            if len(human_hand)==0:
                what_happened="human_wins"
                evaluate()
                break
            print()
            print("--------------------- ΣΕΙΡΑ Η/Υ ----------------------")
            print()
            computer_plays()
        elif what_happened=="computer_played":
            if len(computer_hand)==0:
                what_happened="computer_wins"
                evaluate()
                break
            print()
            print("-------------------- ΣΕΙΡΑ ΠΑΙΚΤΗ --------------------")
            human_plays()
        elif what_happened=="deck_finished":
            evaluate()
            break

# ΚΥΡΙΩΣ ΠΡΟΓΡΑΜΜΑ
print("ΠΑΙΧΝΙΔΙ ΜΕ ΤΡΑΠΟΥΛΟΧΑΡΤΑ (έκδοση 1)")
print("====================================")
print()

# ΚΑΘΟΛΙΚΕΣ ΜΕΤΑΒΛΗΤΕΣ
d=deck()
table=[]
computer_hand=[]
human_hand=[]
what_happened=""

again="y"
while again=="y":
    what_happened="game_start"
    next_turn()
    print("Θέλεις να ξαναπαίξουμε;")
    again=input("γράψε y ή n: ")
print("Τέλος Προγράμματος")


# --------------------------------------------------
# card_game.py (educational version 2.1) in Python 3.5
# 9/6/2016 (25/8/2010) K.Sgarbas
