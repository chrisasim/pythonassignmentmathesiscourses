# -*- coding: utf-8 -*-
from tkinter import *

class MyApp:
    def __init__(self, myParent):
        self.p = myParent
        self.f1 = Frame(myParent)
        self.f1.pack()
        self.w = Label(self.f1, text="  Hello world!   ", font = "Arial 24")
        self.w.pack()
        self.b = Button(self.f1, text="Exit", font = "Arial 30", bg = "yellow", \
                        command = self.buttonPushed)
        self.b.pack(fill=BOTH, expand=1)

    def buttonPushed(self):
        self.p.destroy() # Kill the root window!

#-------------------------------
root = Tk()
root.title('Example 2')
myapp = MyApp(root)
root.mainloop()