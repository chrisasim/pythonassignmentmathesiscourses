# -*- coding: utf-8 -*-
from tkinter import *

class MyApp (Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent)
        self.parent = parent
        self.create_canvas()

    def create_canvas(self):
        self.canvas = Canvas(self.parent, bg = 'white')
        self.canvas.pack(fill = BOTH, expand = 1)
        # το πάτημα του πλήκτρου ποντικιού καλεί το χειριστή new_box
        self.canvas.bind("<Button-1>", self.new_box)
        self.size =100 # πλευρά τετραγώνου
        self.top_left_x, self.top_left_y  = 100, 50 # αρχική θέση τετραγώνου
        bottom_right_x = self.top_left_x + self.size
        bottom_right_y = self.top_left_y + self.size
        self.rect = self.canvas.create_rectangle(self.top_left_x, self.top_left_y,
                    bottom_right_x, bottom_right_y, fill='blue')
    def new_box(self, event):
        # Ο χειριστής λαμβάνει συντεταγμένες event.x, event.y και μετακινεί το rect
        new_x, new_y = event.x, event.y
        delta_x, delta_y = new_x - self.top_left_x, new_y - self.top_left_y
        self.top_left_x, self.top_left_y = new_x, new_y
        # μετακίνηση του τετραγώνου κατά (delta_x, delta_y)
        self.canvas.move(self.rect, delta_x, delta_y)

def main():
    root = Tk()
    root.title("Example 6b: moving blue box")
    root.geometry("400x300+300+300")
    app = MyApp(root)
    root.mainloop()

main()