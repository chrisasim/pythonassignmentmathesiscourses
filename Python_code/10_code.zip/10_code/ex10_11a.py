import tkinter as tk
from tkinter.messagebox import *
from os.path import join
import random
import playing_cards
path="."

class CardGameGUI(tk.Frame)  :
    def __init__(self, root):
        ##### Game parameters
        self.d = playing_cards.Deck()
        self.table = []  # η λίστα με τα χαρτιά στο τραπέζ
        self.computer_hand = []  # τα χαρτιά του υπολογιστή
        self.human_hand = []  # τα χαρτιά του παίκτη
        self.what_happened = "start"  # κατάσταση του παιχνιδιού
        self.drawn_cards = []  # λίστα των εικόνων καρτών παίκτη
        self.generate_card_images()
        ##### GUI parameters
        self.board_width, self.board_hight = 900, 600 # διαστάσεις καμβά
        self.card_width, self.card_hight = 79, 123 # διαστάσεις τραπουλόχαρτου
        self.padx, self.pady = 5,5 # κενό μεταξύ του καμβά και ενεργού περιοχής
        self.f = tk.Frame.__init__(self, root)
        self.f1 = tk.Frame(self.f)
        self.f2 = tk.Frame(self.f, bg='grey')
        self.f1.pack( fill='x')
        self.f2.pack( fill='x')
        self.canvas = tk.Canvas(self.f2, width=self.board_width, \
                                height=self.board_hight, bg='green')
        self.canvas.pack(side='left', fill =  'x')
        self.canvas.bind("<Button-1>", self.board_event_handler)
        self.b = tk.Button(self.f1, text = "Νέο παιχνίδι ", bg='#efefef', \
                           command= self.game_restart)
        self.b.pack(side='left', fill='x')
        self.message =""
        self.score =[0,0]
        self.score_label = tk.Label(self.f1, text= \
            "ΣΚΟΡ : Υπολογιστής {} - Παίκτης {}  ".format(self.score[0], \
            self.score[1]),  font = "Arial 14", fg  = 'brown')
        self.score_label.pack(side = 'right')

    def game_restart(self):
        self.d = playing_cards.Deck()
        self.table = []
        self.computer_hand = []
        self.human_hand = []
        self.what_happened = "start" #what_happened
        self.create_board()

    def generate_card_images(self):
        # δημιουργία εικόνων των καρτών 79x123 px από το spritesheet cards2.gif
        imagefile = join(path,"cards2.gif")
        self.spritesheet = tk.PhotoImage(file= imagefile)
        self.num_sprites = 13
        place = 0
        self.images = {}
        for x in 'sdhc':
            self.images [x] = [self.subimage(79*i, 0+place, \
                        79*(i+1), 123+place) for i in range(self.num_sprites)]
            place += 123
        self.card_back = self.subimage(0,place,79,123 + place)

    def create_board(self):
        if self.what_happened == "start":
            self.initial()
        # περιοχή φύλλων υπολογιστή
        comp_startx, comp_starty = self.padx, self.pady
        comp_endx, comp_endy = self.padx + (len(self.computer_hand)+1)* \
                self.card_width //2 , self.pady+ self.card_hight
        self.comp_plays_area = (comp_startx, comp_starty, comp_endx, comp_endy)
        # περιοχή φύλλων παίκτη
        human_startx, human_starty = self.padx, self.board_hight-self.pady-self.card_hight
        human_endx, human_endy= self.padx+ (len(self.human_hand)+1)*self.card_width//2, \
                                self.board_hight - self.pady
        self.human_plays_area = (human_startx,human_starty, human_endx, human_endy)
        # περιοχή φύλλων τράπουλας
        deck_startx,  deck_starty = 800, 230
        self.deck_of_cards_area = (deck_startx,deck_starty, \
                        deck_startx+self.card_width,deck_starty+self.card_hight)
        # περιοχή ανοικτού φύλλου (table)
        table_startx, table_starty = 360, 230
        self.table_cards_area = (table_startx,table_starty,table_startx+ \
                                 self.card_width,table_starty+self.card_hight)
        # σχεδίασε φύλλα
        self.canvas.delete('all')
        self.drawn_cards = []
        self.score_label.config(text=
            "ΣΚΟΡ : Υπολογιστής {} - Παίκτης {}   ".format(self.score[0], self.score[1]))
        if self.d.cards_left() > 0:
            self.drawn_cards.append( self.drawimage((deck_startx, deck_starty), 'bb'))
            self.canvas.create_text(deck_startx, deck_starty-45, fill="white", \
                text = "Τράπουλα:\nφύλλα:{}".format(self.d.cards_left()), \
                font="Arial 14", anchor = 'nw')
        else:
            self.canvas.create_text(deck_startx-40, deck_starty, fill="white", \
                    text = "Τα φύλλα της \nτράπουλας \nέχουν τελειώσει" + \
                    "\nπάτησε ΕΔΩ \nγια το σκορ\nαν δεν έχεις φύλλο \nνα ρίξεις", \
                    font="Arial 12", anchor = 'nw')
        if len(self.table)>= 1:
            card = str(self.table[-1])
            self.drawn_cards.append(self.drawimage((table_startx, table_starty), card ))
        pos = 0
        for c in self.human_hand:
            card = str(c)
            self.drawn_cards.append(self.drawimage((human_startx+ pos*self.card_width//2, \
                                human_starty), card))
            pos += 1
        self.canvas.create_text(human_startx, human_starty - 30, fill="white", \
                        text = "Παίκτης: φύλλα:{}".format(len(self.human_hand)), \
                        font="Arial 14", anchor = 'nw')
        for item in range(len(self.computer_hand)):
            self.drawn_cards.append(self.drawimage((comp_startx+ item*self.card_width//2, \
                        comp_starty), 'bb'))
        self.canvas.create_text(comp_startx, comp_starty+self.card_hight + 20, \
                fill="white", text = "Υπολογιστής: φύλλα:{}".format(len(self.computer_hand)),
                font="Arial 14", anchor ='nw')
        if self.what_happened in [ "deck_finished", "human_wins", "computer_wins", "END"]:
             showinfo("Τέλος παιχνιδιού", self.message)

    def board_event_handler(self, event):
        x = event.x
        y = event.y
        if self.what_happened == 'END' :
            return
        else:
            if self.in_area(x,y, self.human_plays_area ):
                # Ο χρήστης έχει πατήσει στην περιοχή των φύλλων του,
                # θα πρέπει να βρεθεί το φύλλο που επέλεξε
                w = self.card_width//2
                x0 = x-self.human_plays_area[0]
                card_selected = x0//w
                if card_selected >= len(self.human_hand):
                    card_selected = len(self.human_hand) - 1
                # Καλείται η μέθοδος self.human_plays: έλεγχος αν είναι επιτρεπτή ενέργεια
                if self.human_plays(str(self.human_hand[card_selected])):
                    if self.what_happened == "human_played": # η ενέργεια ήταν επιτρεπτή
                        if len(self.human_hand) == 0:  # αν τέλειωσαν τα φύλλα του χρήστη
                            self.what_happened = "human_wins"
                            self.message = self.evaluate() # τ τελικό μήνυμα
                            self.canvas.after(200, self.create_board)
                            # it returns to redraw the board in the new state
                        else:
                        # ενέργεια ήταν επιτρεπτή αλλά τα φύλλα του χρήστη δεν έχουν τελειώσει
                            self.computer_plays() # καλείται η μέθοδος παίζει ο υπολογιστής
                        # έλεγχος αν τέλειωσαν τα φύλλα του υπολογιστή
                            if len(self.computer_hand) == 0:
                                self.what_happened = "computer_wins"
                                self.message = self.evaluate() # τελικό μήνυμα
                                self.canvas.after(200, self.create_board)
                                # it returns to redraw the board in the new state
                            elif self.what_happened == "deck_finished":
                                self.message = self.evaluate()
                                self.canvas.after(200, self.create_board)
                    # για όποιαδήποτε άλλη περίπτωση, ξανασχεδίασε την επιφάνεια παιχνιδιού
                    self.canvas.after(200, self.create_board)

            elif self.in_area(x,y, self.deck_of_cards_area ):
                # Ο χρήστης έχει πατήσει στην περιοχή της τράπουλας
                if self.human_plays(""): # ο χρήστης τραβάει νέο φύλλο
                    if self.what_happened =="deck_finished": # αν τέλειωσε η τράπουλα
                        self.message = self.evaluate() # έλεγχος για τέλος παιχνιδιού
                        self.canvas.after(200, self.create_board)
                    else:
                        self.canvas.after(200, self.create_board)
                        # exit point to  create the board

    def in_area(self, x,y, rect):
        if x>= rect[0] and x <= rect[2] \
            and y >= rect[1] and y <= rect[3]:
            return True
        else:
            return False

    def subimage(self, l, t, r, b):
        print(l,t,r,b)
        dst = tk.PhotoImage()
        dst.tk.call(dst, 'copy', self.spritesheet, '-from', l, t, r, b, '-to', 0, 0)
        return dst

    def drawimage(self, pos, c):
        x = pos[0]
        y = pos[1]
        if c == 'bb':
            self.new_img = self.canvas.create_image(x,y, image = self.card_back)
            self.canvas.itemconfig (self.new_img, anchor = 'nw')
        else:
            sprite = 'A23456789TJQK'.find(c[0].upper())
            symbol = c[1].lower()
            self.new_img = self.canvas.create_image(x,y, \
                        image = self.images[symbol][sprite])
            self.canvas.itemconfig (self.new_img, anchor = 'nw')
        return self.new_img

    def initial(self):
        self.d.collect()
        self.table = []
        self.computer_hand = []
        self.human_hand = []
        self.d.shuffle()
        print("Μαζεύω τα χαρτιά...Ανακατεύω την τράπουλα...Μοιράζω τα φύλλα...")
        self.table.append(self.d.draw())
        print("Στο τραπέζι έπεσε", self.table[-1]) ########################## event 5
        for i in range(7):
            self.human_hand.append(self.d.draw())
            self.computer_hand.append(self.d.draw())
        if random.random()<0.5:
            print("Στρίβω ένα νόμισμα......Παίζεις πρώτος")
            self.what_happened = "computer_played"
        else:
            print("Στρίβω ένα νόμισμα......Ο Η/Υ παιζει πρώτος")
            self.computer_plays()
            self.what_happened = "human_played"

    def computer_plays(self):
        target_val = self.table[-1].value
        target_sym = self.table[-1].symbol
        while True:
            comp_hand_string = [str(x) for x in self.computer_hand]
            #print("COMPUTER=",comp_hand_string)
            for c in self.computer_hand:
                if c.value ==target_val or c.symbol ==target_sym:
                    print ("Ο Η/Υ ρίχνει",c ) ################  event 1
                    self.computer_hand.remove(c)
                    self.table.append(c)
                    self.what_happened = "computer_played"
                    return
            new_card  =  self.d.draw()
            if new_card  == "empty":
                self.what_happened = "deck_finished"
                return
            else:
                print ("Ο Η/Υ τραβάει φύλλο.")      ################### event 2
                self.computer_hand.append(new_card)

    def human_plays(self, sel):
            if sel =="":
                new_card = self.d.draw()
                print(str(new_card))
                if new_card =="empty":
                    if self.what_happened != 'END' :
                        self.what_happened = "deck_finished"
                    return 1
                else:
                    self.human_hand.append(new_card)
                    human_hand_string = [str(x) for x in self.human_hand]
                    print("HUMAN=",human_hand_string, sel)
                    return 1
            else:
                human_hand_string = [str(x) for x in self.human_hand]
                print("HUMAN=",human_hand_string, sel)
                t = self.table[-1]
                target_val = t.value
                target_sym = t.symbol
                if sel[0] !=  target_val and sel[1] !=  target_sym:
                    print("Δεν επιτρέπεται να ρίξεις το φύλλο ",sel)
                    showinfo("Προσοχή", "Μη επιτρεπτή κίνηση!")
                    return 0
                else:
                    print("Ρίχνεις το",sel) # αυτο δεν χρειαζεται να ανακοινωθει
                    ind = human_hand_string.index(sel)
                    selc = self.human_hand[ind]
                    self.human_hand.remove(selc)
                    self.table.append(selc)
                    self.what_happened = "human_played"
                    return 1

    def evaluate(self):
        out=""
        if self.what_happened =="human_wins":
            out = "Συγχαρητήρια. Κέρδισες!!!"
            self.score[1] += 1
            self.score_label.config(text= \
                "ΣΚΟΡ : Υπολογιστής {} - Παίκτης {}   ".format(self.score[0], self.score[1]))
            self.what_happened = 'END'
        if self.what_happened =="computer_wins":
            out = "Ο Υπολογιστής Κέρδισε."
            self.score[0] += 1
            self.score_label.config(text= \
                "ΣΚΟΡ : Υπολογιστής {} - Παίκτης {}   ".format(self.score[0], self.score[1]))
            self.what_happened = 'END'
        if self.what_happened =="deck_finished":
            ch = len(self.computer_hand)
            if ch == 1: fyl1 = "φύλλο"
            else: fyl1 = "φύλλα"
            hh = len(self.human_hand)
            if hh == 1: fyl2 = "φύλλο"
            else: fyl2 = "φύλλα"
            out = "Η τράπουλα τελείωσε, ο Υπολογιστής έχει "+ \
                  "{} {} και εσύ έχεις {} {}\n".format(ch, fyl1, hh, fyl2)
            if ch>hh:
                out += "Συγχαρητήρια. Κέρδισες!!!"
                self.score[1] += 1
                self.score_label.config(text= \
                    "ΣΚΟΡ : Υπολογιστής {} - Παίκτης {}   ".format(self.score[0], self.score[1]))
                self.what_happened = 'END'
            if ch<hh:
                out += "Ο Υπολογιστής κέρδισε."
                self.score[0] += 1
                self.score_label.config(text= \
                    "ΣΚΟΡ : Υπολογιστής {} - Παίκτης {}   ".format(self.score[0], self.score[1]))
                self.what_happened = 'END'
            if ch ==hh:
                out+="Ισοπαλία ( ο υπολογιστής και συ έχετε τον ίδιο αριθμό φύλλων )"
                self.what_happened = 'END'
        return out

root = tk.Tk()
root.title("Card Game")
root.resizable(width='false', height='false')
app = CardGameGUI(root)
root.mainloop()

# cardgame gui based on cardgame v.2 (Python 3.0 version)
# N Avouris 7/2/2016