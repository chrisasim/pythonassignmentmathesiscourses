# -*- coding: utf-8 -*-
from tkinter import *
class MyApp:
    def __init__(self, myParent):
        self.p = myParent
        self.f1 = Frame(myParent)
        self.f1.pack()
        self.button = Button(self.f1, text="  show text  ", font = "Arial 30", \
		bg = "yellow", command = self.showText)
        self.button.pack(fill=BOTH, expand=1)
        self.entry = Entry(self.f1, font = "Arial 24") # το πλαίσιο εισαγωγής κειμένου
        self.entry.pack(fill=BOTH, expand=1)
    def showText(self): # χειριστής γεγονότος επιλογής πλήκτρου b
        text = self.entry.get() # πάρε το κείμενο που έχει εισαχθεί στο πλαίσιο κειμένου
        print(text) # τύπωσε το
#-------------------------------
root = Tk()
root.title('Example 3')
myapp = MyApp(root)
root.mainloop()