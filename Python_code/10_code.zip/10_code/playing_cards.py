# -*- coding: utf-8 -*-
# playing_cards.py (in Python v3.0)

import random

class Card():
    def __init__(self,val,sym):
        self.value=val
        self.symbol=sym
        if self.symbol in "sc": self.color='B'
        else: self.color='R'
        if self.value in "JQK": self.fig=True
        else: self.fig=False
    def __str__(self):
        return self.value+self.symbol

    def detailed_info(self):
        print ('Αξία=',self.value, '    Σύμβολο=',self.symbol)
        print ('Χρώμα=',self.color, '    Φιγούρα=',self.fig)

class Deck():
    values="A23456789TJQK"  # Όλες οι αξίες
    symbols="shcd"          # Όλα τα σύμβολα
    #content=[]
    #pile=[]
    def __init__(self):
        self.content=[] # Χαρτιά που βρίσκονται στην τράπουλα
        self.pile=[]    # Χαρτιά που βγήκαν από την τράπουλα
        for s in Deck.symbols:
            for v in Deck.values:
                c=Card(v,s)
                self.content.append(c)
    def __str__(self):
        s=""
        cntr=0
        for i in self.content:
            s=s+str(i)+" "
            cntr=cntr+1
            if cntr%13==0: s=s+'\n'
        if s[-1] != '\n': s=s+'\n'
        s=s+str(len(self.content))+"-"+str(len(self.pile))
        return s
    def shuffle(self):
        random.shuffle(self.content)
    def draw(self):
        if len(self.content)<1: return "empty"
        c=self.content[0]
        self.content=self.content[1:]
        self.pile.append(c)
        return c
    def collect(self):
        self.content=self.content+self.pile
        self.pile=[]
    def cards_left(self):
        return len(self.content)

class Pack(Deck):
    def __init__(self,number_of_decks=2):
        d=deck()
        self.content=d.content*number_of_decks
        self.pile=[]


# -------------------------------------------------------
# playing_cards.py (educational version 2) in Python v2.7
# 24/11/2015 (25/8/2010) K.Sgarbas