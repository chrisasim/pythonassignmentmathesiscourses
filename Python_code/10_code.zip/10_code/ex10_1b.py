# -*- coding: utf-8 -*-
from tkinter import *
class MyApp:
    def __init__(self, myParent):
        self.f1 = Frame(myParent)
        self.f1.pack()
        self.w = Label(self.f1, text="  Hello world!   ", \
                       font = "Arial 24")
        self.w.pack()
#-------------------------------
root = Tk()
root.title('Example 1b')
myapp = MyApp(root)
root.mainloop()
