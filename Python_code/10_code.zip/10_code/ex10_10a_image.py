from tkinter import *
import os.path

class App(Frame)  :
    def __init__(self, root):
        Frame.__init__(self, root)
        self.root = root
        self.create_widgets()

    def create_widgets(self):
        self.canvas = Canvas(self.root, bg='green')
        self.canvas.pack(side='left', fill =  BOTH)
        self.img = PhotoImage(file=os.path.join('.',"Queen_hearts.gif"))
        self.canvas.create_image(30,20, image = self.img, anchor=NW)

def main():
    root = Tk()
    root.title("ex.10. cards")
    root.geometry("150x200+300+300")
    app = App(root)
    root.mainloop()

main()