# -*- coding: utf-8 -*-
from tkinter import *
import tkinter.simpledialog as sd
import tkinter.colorchooser as col

class MyApp (Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent)
        self.parent = parent
        self.menubar = Menu(self.parent)
        self.selection = Menu(self.menubar, tearoff=0)
        self.menubar.add_cascade(  label="Επιλογές           ", menu=self.selection)
        self.selection.add_command(label="Χρώμα γραμμής", command=self.color_select)
        self.selection.add_command(label="Πάχος γραμμής", command=self.line_select)
        self.selection.add_command(label="Καθάρισμα ζωγραφιάς", command=self.clear_all)
        self.selection.add_separator()
        self.selection.add_command(label="Έξοδος", command=self.parent.destroy)
        self.parent.config(menu = self.menubar)
        self.create_canvas()
        self.line_color = 'black' # default line drawing color
        self.line_width = 2

    def create_canvas(self):
        self.canvas = Canvas(self.parent, bg = '#ffffff')
        self.canvas.pack(fill = BOTH, expand = 1)
        self.canvas.bind("<Button-1>", self.start_draw)
        self.canvas.bind("<B1-Motion>", self.draw_line)

    def color_select(self):
        color = col.askcolor(initialcolor = self.line_color, parent =  self.parent, \
                             title = "Επιλογή χρώματος γραμμής")
        print(color)
        if color[1]:
            self.line_color = color[1]

    def line_select(self):
        line = sd.askstring("Επιλογή πάχους γραμμής", \
                            "Παρακαλώ δώσε το πάχος γραμμής [1-10]")
        try:
            line = int(line)
            if 0 < line < 11 : self.line_width = line
        except: pass

    def clear_all(self):
        self.canvas.delete("all")

    def start_draw(self, event):
        self.lastx, self.lasty = event.x, event.y

    def draw_line(self, event):
        self.canvas.create_line((self.lastx, self.lasty, event.x, event.y), fill = self.line_color, width = self.line_width)
        self.lastx, self.lasty = event.x, event.y

def main():
    root = Tk()
    root.title("Example 9: draw app + menu")
    root.geometry("600x500+300+300")
    app = MyApp(root)
    root.mainloop()

if __name__ == '__main__':
    main()