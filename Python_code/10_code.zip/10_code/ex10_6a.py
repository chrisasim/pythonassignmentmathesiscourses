# -*- coding: utf-8 -*-
from tkinter import *

class MyApp (Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent)
        self.parent = parent
        self.create_canvas()

    def create_canvas(self):
        self.canvas = Canvas(self.parent, bg = 'white')
        self.canvas.pack(fill = BOTH, expand = 1)
        size =200
        top_left_x, top_left_y = 100, 50
        bottom_right_x = top_left_x + size
        bottom_right_y = top_left_y + size
        # δημιουργία τετράγωνου στη θέση top_left_x, top_left_y
        # με πλευρά size
        self.canvas.create_rectangle(top_left_x, top_left_y,
                    bottom_right_x, bottom_right_y, fill='red')

def main():
    root = Tk()
    root.title("Example 6a: red box")
    root.geometry("400x300+300+300") #  παραθύρου 400 x 300 στη θέση (300,300)
    app = MyApp(root)
    root.mainloop()

main()