from tkinter import *
import tkinter.messagebox as ms
from os.path import join
path="."

class App(Frame)  :
    def __init__(self, root):
        Frame.__init__(self, root)
        self.root = root
        self.create_widgets()

    def create_widgets(self):
        self.f1 = Frame(self.root, bg='green')
        self.f1.pack(fill = BOTH, expand = 1)
        self.f2 = Frame(self.root, bg='green')
        self.f2.pack(fill = BOTH, expand=1)
        self.requested_card = StringVar()
        self.requested_card.set( "")
        self.l = Label(self.f1, text = "Δώσε κάρτα :", bg='#efefef', font='Arial 14')
        self.l.pack(side='left', fill= BOTH)
        self.e = Entry(self.f1, textvariable = self.requested_card, fg='grey', font='Arial 14').pack()
        self.canvas = Canvas(self.f2, bg='green')
        self.canvas.pack(side='left', fill =  BOTH)
        self.root.bind('<Return>', self.select_image)
        self.generate_images_from_sprite()

    def generate_images_from_sprite(self):
        imagefile = join(path,"cards2.gif")
        self.spritesheet = PhotoImage(file= imagefile)
        self.num_sprites = 13
        self.cards = []
        place = 0
        self.images = {}
        for x in 'sdhc':
            self.images [x] = [self.subimage(79*i, 0+place, 79*(i+1), 123+place) for i in range(self.num_sprites)]
            place += 123

    def select_image(self, event):
        #print ("card=",self.requested_card())
        card = self.requested_card.get()
        self.cards = card.split(",")
        error = False
        for card in self.cards:
            card = card.strip()
            if card[1].lower() in "scdh" and card[0].upper() in "A23456789TJQK":
                self.drawimage((30,20), card)
            else:
                error = True
        if error:
            ms.showinfo("Προσοχή",  "Λίστα από κάρτες που δίνονται ως τιμή-σύμβολο, με τιμές A,2-9,T,J,Q,K και σύμβολα s,d,h,c ")
        self.requested_card.set("")

    def subimage(self, l, t, r, b):
        #print(l,t,r,b)
        dst = PhotoImage()
        dst.tk.call(dst, 'copy', self.spritesheet, '-from', l, t, r, b, '-to', 0, 0)
        return dst

    def drawimage(self, pos, card):
        x = pos[0]
        y = pos[1]
        print ("drawimage", pos, card)
        sprite = 'A23456789TJQK'.find(card[0].upper())
        symbol = card[1].lower()
        self.new_img = self.canvas.create_image(x,y, image = self.images[symbol][sprite], anchor = NW)
        #self.canvas.itemconfig (self.new_img, anchor = 'nw')
        return self.new_img

def main():
    root = Tk()
    root.title("ex.10. cards")
    root.geometry("150x200+300+300")
    app = App(root)
    root.mainloop()

main()