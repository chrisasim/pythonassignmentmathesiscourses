# -*- coding: utf-8 -*-
from tkinter import *

class MyApp (Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent)
        self.parent = parent
        self.create_canvas()

    def create_canvas(self):
        self.canvas = Canvas(self.parent, bg = '#e0e0ff')
        self.canvas.pack(fill = BOTH, expand = 1)
        self.canvas.bind("<Button-1>", self.start_draw)
        self.canvas.bind("<B1-Motion>", self.draw_line)

    def start_draw(self, event):
        self.lastx, self.lasty = event.x, event.y

    def draw_line(self, event):
        self.canvas.create_line((self.lastx, self.lasty, \
                    event.x, event.y), fill = 'black', width =2)
        self.lastx, self.lasty = event.x, event.y

def main():
    root = Tk()
    root.title("Example 8: draw app")
    root.geometry("800x600+300+300")
    app = MyApp(root)
    root.mainloop()

if __name__ == '__main__':
    main()