# -*- coding: utf-8 -*-
from tkinter import *

class MyApp:
    def __init__(self, myParent):
        self.p = myParent
        self.f1 = Frame(myParent)
        self.f1.pack()
        color1 = '#66f0ff'
        self.l = Label(self.f1, text = 'Επιλέξτε τα σπορ που σας αρέσουν: ',\
                font = "Arial 12", bg = color1)
        self.l.pack(fill = BOTH, expand =1)
        self.answer1 = StringVar()
        self.check1 = Checkbutton(self.f1, text='football ',
                    command= self.check, font = "Arial 20",bg = color1, \
                    variable = self.answer1, onvalue='football', offvalue='')
        self.check1.pack(fill = BOTH, expand = 1)
        self.answer2 = StringVar()
        self.check2 = Checkbutton(self.f1, text='basket ', command= self.check,\
                    font = "Arial 20",bg = color1, variable = self.answer2, \
                    onvalue='basket', offvalue='')
        self.check2.pack(fill = BOTH, expand = 1)
        self.count = 0
    def check(self):
        print('Έχουν επιλεγεί: ', self.answer1.get(), self.answer2.get())

#-------------------------------
root = Tk()
root.title('Example 5')
myapp = MyApp(root)
root.mainloop()
