# -*- coding: utf-8 -*-
from tkinter import *

class MyApp (Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent)
        self.parent = parent
        self.create_widgets()

    def create_widgets(self):
        self.parent.bind("<Key>", self.handler)
        self.parent.bind("<Button-1>", self.focus)
        self.myText = StringVar()
        #self.myText.set(30*'_')
        self.mylabel = Label(self.parent, textvariable = self.myText, \
                             font = "Arial 30",bg="yellow")
        self.mylabel.pack(fill = BOTH, expand = 1)

    def handler(self, event):
        print("πατήθηκε: "+repr(event.char))
        self.myText.set( "πατήθηκε: "+str(event.char))
    def focus(self, event):
        self.parent.focus_set()
        print ("clicked at", event.x, event.y)
        self.myText.set( "κλικ σε: " + str(event.x) + "," + str(event.y))

def main():
    root = Tk()
    root.title("Example 7: detecting events")
    root.geometry("300x100+300+300")
    app = MyApp(root)
    root.mainloop()

main()
