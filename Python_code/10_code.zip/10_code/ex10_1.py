# -*- coding: utf-8 -*-
from tkinter import *
root = Tk() # Δημιουργία παράθυρου root
root.title('Example 1')
# δημιουργία label
w = Label(root, text = "   Hello, world!  ", font = 'Arial 24')
w.pack() # τοποθέτηση w στο παράθυρο
root.mainloop() # έναρξη βρόχου γεγονότων χρήστη
