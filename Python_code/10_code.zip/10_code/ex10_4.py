# -*- coding: utf-8 -*-
from tkinter import *

class MyApp:
    def __init__(self, myParent):
        self.p = myParent
        self.f1 = Frame(myParent)
        self.f1.pack()
        self.myText = StringVar()
        self.myText.set(30*'_')
        self.mylabel = Label(self.f1, textvariable = self.myText, \
				font = "Arial 20")
        self.mylabel.pack(fill=BOTH, expand=1)
        self.b = Button(self.f1, text="  button  ", font = "Arial 30", \
			bg = "yellow", command = self.buttonPressed)
        self.b.pack(fill=BOTH, expand=1)
        self.count = 0
    def buttonPressed(self):
        self.count += 1
        if self.count < 10: sp = '  '
        else: sp = ''
        if self.count == 1 : end =  'ά '
        else: end = 'ές'
        self.myText.set('Το πλήκτρο πατήθηκε ' + sp + str(self.count) \
			+ ' φορ'+end)

#-------------------------------
root = Tk()
root.title('Example 4')
myapp = MyApp(root)
root.mainloop()
