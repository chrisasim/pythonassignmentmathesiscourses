from bs4 import BeautifulSoup
import urllib.request
YEAR = '2016'

def search_for_unis(url1):
    unis = []
    #this will look for all universities found in url1
    with urllib.request.urlopen(url1) as response:
        html  = response.read()
    soup = BeautifulSoup(html)
    for tag in soup.find_all():
        if tag.name == 'h2':
            uni_name = tag.get_text()
            if uni_name not in unis and uni_name not in ['Λίστα Ιδρυμάτων και Τμημάτων', 'Περιεχόμενα']:
                unis.append(uni_name)
    return unis

def search_for_departments(url, university):
    print(university)
    # search for the departments of uni in page url
    with urllib.request.urlopen(url) as response:
        h  = response.read()
    soup = BeautifulSoup(h)
    # search for university in list
    uni=False
    depts={}
    acad_year = str(int(YEAR)-1)  + " - " + str(YEAR)
    print ("Academic year = ", acad_year)
    for tag in soup.find_all():
        if tag.name == 'h2':
            if university in tag.get_text() :
                uni = True
            else:
                uni = False
        if uni:
            if tag.name == 'p':
                department = tag.get_text()
                if department not in depts.keys():
                    depts[department] = ""
            if tag.name == 'a' :
                if acad_year in tag.get_text() :
                    url2 = tag['href']
                    url2= "https://service.eudoxus.gr"+url2
                    depts[department] = url2
    return depts

def main():
    url1 = 'https://service.eudoxus.gr/public/departments'
    u = search_for_unis(url1)
    for uni in u:
        print(uni)
        d = search_for_departments(url1, uni)
        for dept in d:
            print("...", dept, d[dept])
        x = input("x for exit")
        if x == "x":
            break

if __name__ == '__main__':
    main()