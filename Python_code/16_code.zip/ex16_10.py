# -*- coding: utf-8 -*-
import xml.etree.ElementTree as et
data = '''
<all>
    <book isbn="123">
        <title>Τα πάντα για την Python</title>
        <author>Πύθων ο Γεμιστός</author>
    </book>
    <book isbn="456">
        <title>Ανωτάτη Πυθωνική</title>
        <author>Σχολάριος</author>
    </book>
</all>'''

tree = et.fromstring(data)
lst = tree.findall('book')
print("Αριθμός βιβλίων:", len(lst))
for book in lst:
    print('Τίτλος:', book.find('title').text)
    print('Συγγραφεύς:', book.find('author').text)