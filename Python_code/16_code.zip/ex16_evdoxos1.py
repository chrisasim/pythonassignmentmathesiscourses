from bs4 import BeautifulSoup
html_file = open('universities.html','r')
soup = BeautifulSoup(html_file, 'html.parser')
print(soup.title)
print(soup.meta)
print(soup.meta['charset'])
for tag in soup.find_all('tr'):
    list_of_children = list(tag.children)
    print (list_of_children[1].get_text().strip())
