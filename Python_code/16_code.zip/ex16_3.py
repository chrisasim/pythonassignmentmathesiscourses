from bs4 import BeautifulSoup
import urllib.request
YEAR = '2016'

def search_for_unis(url1):
    unis = []
    #this will look for all universities found in url1
    with urllib.request.urlopen(url1) as response:
        html  = response.read()
    soup = BeautifulSoup(html)
    for tag in soup.find_all():
        if tag.name == 'h2':
            uni_name = tag.get_text()
            if uni_name not in unis and uni_name not in ['Λίστα Ιδρυμάτων και Τμημάτων', 'Περιεχόμενα']:
                unis.append(uni_name)
    return unis

url1 = 'https://service.eudoxus.gr/public/departments'
u = search_for_unis(url1)
for uni in u:
    print(uni)