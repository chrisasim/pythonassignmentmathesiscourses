# -*- coding: utf-8 -*-
import urllib.request
url =  'https://service.eudoxus.gr/public/departments'
try:
    html_example = urllib.request.urlopen(url)
    for line in html_example:
        line_printable = line.decode()
        if len(line_printable.strip()) > 0:
            print(line_printable[:-1])
except:
    print('Error in opening', url)