import json
json_data = '''{"coord":{"lon":139,"lat":35},
"sys":{"country":"JP","sunrise":1369769524,"sunset":1369821049}}'''
json_python = json.loads(json_data)
for key in json_python:
    print(key,": ", json_python[key])
