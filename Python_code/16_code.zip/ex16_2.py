from bs4 import BeautifulSoup
import urllib.request
YEAR = '2016'

def search_for_departments(url, university):
    print(university)
    # search for the departments of uni in page url
    with urllib.request.urlopen(url) as response:
        h  = response.read()
    soup = BeautifulSoup(h)
    # search for university in list
    uni=False
    depts={}
    acad_year = str(int(YEAR)-1)  + " - " + str(YEAR)
    print ("Academic year = ", acad_year)
    for tag in soup.find_all():
        if tag.name == 'h2':
            if university in tag.get_text() :
                uni = True
            else:
                uni = False
        if uni:
            if tag.name == 'p':
                department = tag.get_text()
                if department not in depts.keys():
                    depts[department] = ""
            if tag.name == 'a' :
                if acad_year in tag.get_text() :
                    url2 = tag['href']
                    url2= "https://service.eudoxus.gr"+url2
                    depts[department] = url2
    return depts

print(search_for_departments('https://service.eudoxus.gr/public/departments', 'ΑΝΩΤΑΤΗ ΣΧΟΛΗ ΚΑΛΩΝ ΤΕΧΝΩΝ'))