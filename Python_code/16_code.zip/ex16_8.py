# -*- coding: utf-8 -*-
import urllib.request
import datetime
import json

apikey="19787348fd056a5fe2d3387b4537c6a9"
# this is a key obtained by signing up in http://home.openweathermap.org/

def display_final(data):
    print("City: ", data['name'], 'Country : '+ str(data['country']), end='')
    print('   [Latitude :  '+'%.3f'%(float(data['lat'])), 'Longitude: '+
          '%.3f'%(float(data['lon'])),']')
    print("Date time:", time_stamp_to_data(data['dt']))
    print(data['description'])
    #temperature note: the api sends the temperature in kelvin
    tempr = float(data['temp'])- 273.15 # kelvin to Celcius
    to_print = str('%.1f'%(float(data['temp_min'])- 273.15))+u' \u2103'+ \
               ' ~ ' + str('%.1f'%(float(data['temp_max'])- 273.15))+u' \u2103'
    print('Θερμοκρασία (min ~ max):', to_print)
    print(str('%.1f' % tempr)+u' \u2103', end='') #celcius
    print('/ ', str('%.1f' % celcius_to_fahrenheit(tempr)) +u' \u2109') #fahrenheit
    #humidity
    print('Σχετική υγρασία: ', data['humidity']+' %' ) #rh
    #Wind Speed
    print('Ταχύτητα ανέμου: ', data['speed']+' m/s ' ) #rh
    #Wind Degree
    if 'deg' in data:
        print('Άνεμοι', wind_direction(float(data['deg']))  ) #rh
    #atmoshpheric pressure
    if 'pressure' in data:
        print('Ατμ.Πίεση(at.)', data['pressure']+' millibars') #rh
    #rain in last 3 hours
    if '3h' in data :
        print('Βροχή (Last 3h)', data['3h']+' mm' ) #rain
    #clouds
    print('Σύννεφα', data['all']+' %' ) #clouds
    #sunrise
    print('Ανατολή', time_stamp_to_time(data['sunrise']), end='' )
    #sunsettime_stamp_to_data
    print('   - Δύση', time_stamp_to_time(data['sunset']) )

def time_stamp_to_time(ts):
    return (datetime.datetime.fromtimestamp\
                (int(ts)).strftime('%H:%M:%S'))

def time_stamp_to_data(ts):
    #ts = utc_to_local(ts)
    return (datetime.datetime.fromtimestamp\
                (int(ts)).strftime('%Y-%m-%d %H:%M:%S'))

def celcius_to_fahrenheit(c):
    return (float(c) * 9.0/5) + 32.0

def wind_direction(grad):
    if grad > 348.75 or grad <= 11.25: wind ='N Βόρειοι'
    elif grad > 11.25 and grad <= 33.75: wind = 'NNE Βόρειοι-Βορειοανατολικοί'
    elif grad > 33.75 and grad <= 56.25: wind = 'NE Βορειοανατολικοί'
    elif grad >  56.25 and grad <= 78.75: wind = 'ENE Ανατολικοί-Βορειοανατολικοί'
    elif grad > 78.75 and grad <= 101.25: wind = 'E Ανατολικοί'
    elif grad >101.25 and grad <= 123.75: wind = 'ESE Ανατολικοί-Νότιονανατολικοί'
    elif grad >123.75 and grad <= 146.25: wind = 'SE Νότιονανατολικοί'
    elif grad >146.25 and grad <= 168.75 : wind = 'SSE Νότιοι-Νότιονανατολικοί'
    elif grad >168.75 and grad <= 191.25: wind = 'S Νότιοι'
    elif grad >191.25 and grad <= 213.75 : wind = 'SSW Νότιοι-Νότιοδυτικοί'
    elif grad >213.75 and grad <= 236.25 : wind = 'SW Νότιοδυτικοί'
    elif grad >236.25 and grad <= 258.75 : wind = 'WSW Δυτικοί-Νότιοδυτικοί'
    elif grad >258.75 and grad <= 281.25: wind = 'W Δυτικοί'
    elif grad >281.25 and grad <= 303.75: wind = 'WNW Δυτικοί-Βόρειοδυτικοί'
    elif grad >303.75 and grad <= 326.25 : wind = 'NW Βόρειοδυτικοί'
    elif grad >326.25 and grad <= 348.75: wind = 'NNW Βόρειοι-Βόρειοδυτικοί'
    else: wind = ''
    return wind

def get_weather_data(city):
    '''In Python 3, binary data, such as the raw response of a http request, is stored in bytes objects.
    json/simplejson expects strings. The solution is to decode the bytes data to string data with the appropriate
    encoding, which you can find in the header. You find the encoding with: encoding = req.headers.get_content_charset()
    You then make the content a string by: body = req.readall().decode(encoding) This body you then can pass to the
    json loader.
    '''
    try:
        apiurl = 'http://api.openweathermap.org/data/2.5/weather?q=%s&APPID=%s'% (city.encode('utf-8'), apikey)
        data =  urllib.request.urlopen(apiurl)
        encoding = data.headers.get_content_charset()
        jdata = json.loads(data.read().decode(encoding))
        return jdata
    except IOError as e:
        print('Αδύνατη σύνδεση', 'Σφάλμα %s'%e)
        return {'message': e}

def json_to_dict(jdata):
    flatteneddict = {}
    for key, value in jdata.items():
        #print ('K,v', key, value)
        if key == 'weather':
            for ke,va in value[0].items():
                    flatteneddict[str(ke)] = str(va).upper()
            continue
        try:
            for k,v in value.items():
                    flatteneddict[str(k)] = str(v).upper()
        except:
            flatteneddict[str(key)] = str(value).upper()
    return flatteneddict

def main():
    city = ''
    while city != 'x':
        city = input('Δώσε όνομα πόλης: ')
        data = get_weather_data(city)

        if ('message' in data.keys()):
            print(data['message'])
        else:
            data = json_to_dict(data)
            display_final(data)
        print(30 * '=')

if __name__ == '__main__':
    main()



