# -*- coding: utf-8 -*-
import sqlite3 as lite
import os.path
db_name = "syggrammata.sqlite"
dir = '.'
db = os.path.join(dir, db_name)

class uni():
    def __init__(self,name):
        self.name = name
        self.dept =[]

    def create_dept(self, dept_name, dept_code=""):
        self.dept.append(dept(dept_name, dept_code))

    def get_depts(self):
        return dept

    def __str__(self):
        return self.name

class dept(uni):
    def __init__(self, uni, name, code):
        self.name = name
        self.code = code
        self.city =''
        self.no_stud = None

    def set_city(self, city):
        self.city = city

    def set_no_stud(selfself,no_stud):
        self.no_stud = no_stud

    def get_dept(self, code):
        if self.code == code:
            return self.name
        else:
            return 0

class course():
    def __init__(self, uni, dept, code, name, semester="", autumn=""):
        self.uni = str(uni)
        self.dept = str(dept)
        self.code = str(code)
        self.name = name
        self.semester = str(semester)
        self.autumn = autumn

    def get_code(self):
        return self.code

    def __str__(self):
        return self.uni+"-"+self.dept+";"+self.code+";"+ self.name+";"+str(self.semester)+";"+self.autumn

    def get_course(self):
        return self.code+"\t"+ self.name+"\t"+str(self.semester)+"\t"+self.autumn

class book():
    def __init__(self, code, name):
        self.code = code
        self.name = name

    def __str__(self):
        return self.code+";"+self.name

    def get_code(self):
        return self.code


class relate_course_book(course, book):
    def __init__(self, c, b):
        self.course = c
        self.book =  b

    def get_book(self):
        return self.book

    def get_course(self):
        return self.course

    def get_relation(self):
        return (self.course, self.book)

    def __str__(self):
        return self.course.code+";"+self.course.name+";"+self.book.code+";"+self.book.name

def greek_to_upper(w):
    gr_up = {'Ύ':'Υ', 'Έ':'Ε', 'Ά':'Α', 'Ό':'Ο', 'Ί':'Ι', 'Ή':'Η', 'Ώ':'Ω'}
    w_up = w.upper().strip()
    for x in gr_up:
        w_up = w_up.replace(x, gr_up[x])
    return w_up

def establish_set_of_keywords(keyword):
    keyword = keyword.strip()
    terms =[keyword]
    if keyword.upper() == keyword :
        key_l = keyword.lower()
        terms.append(keyword.lower())
        terms.append(keyword.title())
        terms.append(keyword.capitalize())
        key_title = key_l.title()
    else:
        key_u = keyword.upper()
        terms.append(key_u)
        # eliminated accedent characters from capital letters
        key_u = key_u.replace('Ύ','Υ')
        key_u = key_u.replace('Έ','Ε')
        key_u = key_u.replace('Ά','Α')
        key_u = key_u.replace('Ό','Ο')
        key_u = key_u.replace('Ί','Ι')
        key_u = key_u.replace('Ή','Η')
        key_u = key_u.replace('Ώ','Ω')
        terms.append(key_u)
    return (set(terms))

def get_uni_name(uni_id):
    try:
        con = lite.connect(db)
        with con:
            con.row_factory = lite.Row
            cur = con.cursor()
            cur.execute("SELECT name FROM universities where id = ?", (uni_id,))
            row = cur.fetchone()
            if len(row['name']) > 0 : return row['name']
            else:
                return 0
    except lite.Error as e:
        print("error in opening table universities", e)
        return 0

def get_uni_id(uni_name):
    try:
        con = lite.connect(db)
        with con:
            con.row_factory = lite.Row
            cur = con.cursor()
            cur.execute("SELECT id FROM universities where name = ?", (uni_name,) )
            row = cur.fetchone()
            uni_id =row[0]
            return uni_id
    except lite.Error as e:
        print("error in opening table universities", e)
        return 0


def get_uni_list1():
    try:
        con = lite.connect(db)
        with con:
            cur = con.cursor()
            cur.execute("SELECT id, name FROM universities ")
            rows = cur.fetchall()
            return rows
    except lite.Error as e:
        print("error in opening table universities", e)
        return 0

def get_uni_list2():
    try:
        con = lite.connect(db)
        with con:
            con.row_factory = lite.Row
            cur = con.cursor()
            cur.execute("SELECT id, name FROM universities ")
            rows = cur.fetchall()
            unis = []
            for row in rows:
                unis.append([row['id'], row['name']])
            return unis
    except lite.Error as e:
        print("error in opening table universities", e)
        return 0

def get_dept_list(uni_name):
    uni_id = get_uni_id(uni_name)
    try:
        con = lite.connect(db)
        with con:
            cur = con.cursor()
            cur.execute("SELECT id, name FROM departments where uni_id = ?", (uni_id,) )
            rows = cur.fetchall()
            return rows
    except lite.Error as e:
        print("error in opening table universities", e)
        return 0

def get_dept_id(dept_name, uni_id):
    try:
        con = lite.connect(db)
        with con:
            con.row_factory = lite.Row
            cur = con.cursor()
            cur.execute("SELECT id FROM departments where uni_id = ? and name = ?", (uni_id, dept_name))
            row = cur.fetchone()
            if len(row['id']) > 0 : return row['id']
            else:
                return 0
    except lite.Error as e:
        print("error in opening table departments", e)
        return 0

def get_dept_name(dept):
    try:
        con = lite.connect(db)
        with con:
            con.row_factory = lite.Row
            cur = con.cursor()
            cur.execute("SELECT name FROM departments where id = ?", (dept,))
            row = cur.fetchone()
            if len(row[0]) > 0 : return row[0]
            else:
                return 0
    except lite.Error as e:
        print("error in opening table departments", e)
        return 0

def get_uni_of_dept(dept):
    try:
        con = lite.connect(db)
        with con:
            con.row_factory = lite.Row
            cur = con.cursor()
            cur.execute("SELECT uni_id FROM departments where id = ?", (dept,))
            row = cur.fetchone()
            if row[0] > 0 : return get_uni_name(row[0])
            else:
                return -1
    except lite.Error as e:
        print("error in opening table departments", e)
        return -1

def dept_program(uni_name,dept_name, dept):
    dept = str(dept)
    try:
        con = lite.connect(db)
        with con:
            con.row_factory = lite.Row
            cur = con.cursor()
            cur.execute("SELECT * FROM courses where dept_id = ?", (dept,))
            rows = cur.fetchall()
            courses = []
            for row in rows:
                code=row["code"]
                name = row["name"]
                sem = row["semester"]
                spr = row["spring_winter"]
                c = course(uni, dept, code, name, sem, spr)
                courses.append(c)
            prog ={}
            for c in courses:
                if int(c.semester) in prog.keys():
                    prog[int(c.semester)].append(c)
                else:
                    prog[int(c.semester)] = [c]
            ################# print the program ##########################
            print( 50*'='+'\n'+uni_name+"\nTMHMA " + dept_name)
            for sem in sorted(prog):
                print( "\nΕξάμηνο :"+str(sem))
                for c in prog[sem]:
                    print(c.code, c.name)
                x = input('enter να συνεχίσει, x να σταματήσει')
                if x == 'x' :return
            return
    except lite.Error as e:
        print("error in opening table courses", e)


def depts_of_university(uni) :
    try:
        conn = lite.connect(db)
        conn.row_factory = lite.Row
        depts = []
        with conn:
            cur = conn.cursor()
            cur.execute("SELECT id,name FROM departments where uni_id = ?", (uni,))
            rows = cur.fetchall()
            for row in rows:
                depts.append([row[0], row[1]])
        return depts
    except lite.Error as e:
        print('error openning table departments')

def main():
    while True:
        university_list = get_uni_list1()
        if university_list:
            for university in university_list:
                print (university)
            u = input('Επιλέξτε πανεπιστήμιο (enter για έξοδο):')
            try:
                u1 = int(u)
            except:
                break
            if u1 in [x[0] for x in university_list] :
                uni_name = [x[1] for x in university_list if x[0] == u1][0]
                print('ΤΑ ΤΜΗΜΑΤΑ ΣΤΟ {} EINAI:'.format(uni_name))
                dept_list = depts_of_university(u)
                for department in dept_list:
                    print (department)
                selected_dept = input("Επιλέξτε Τμήμα: (enter για έξοδο):'")
                try:
                    selected_dept = int(selected_dept)
                    if selected_dept in [x[0] for x in dept_list]:
                        dept_name = [x[1] for x in dept_list if x[0] == selected_dept][0]
                        dept_program(uni_name, dept_name,selected_dept)
                    else:
                        print('Πρέπει να δώσεις έγκυρο κωδικό Τμήματος')
                        break
                except:
                    pass
            else:
                print('Πρέπει να δώσεις έγκυρο κωδικό Πανεπιστημίου')
        else: break

def get_create_table():
    f = os.path.join(dir, 'syggrammata.sql')
    with open(f, 'r')as fo:
        for line in fo:
            if 'CREATE' in line:
                print (line)

if __name__ == '__main__':
    main()
    #get_create_table()
