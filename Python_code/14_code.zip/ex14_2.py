from pymongo import MongoClient

con = MongoClient()

db = con.syggrammata
books = db.books # a mongodb collection equivalent to a table

books.remove()
try:
    books.insert({'_id':'6', 'title':'ΒΙΟΛΟΓΙΑ ΚΥΤΤΑΡΟΥ', 'author':' ΒΑΣΙΛΗΣ ΜΑΡΜΑΡΑΣ & ΜΑΡΙΑ ΛΑΜΠΡΟΠΟΥΛΟΥ-ΜΑΡΑΜΑΡΑ'})
    books.insert({'_id':'8', 'title':'ΕΙΣΑΓΩΓΗ ΣΤΟΥΣ ΥΠΟΛΟΓΙΣΤΕΣ', 'author':' ΝΙΚΟΛΑΟΣ ΑΒΟΥΡΗΣ, ΟΔΥΣΣΕΑΣ ΚΟΥΦΟΠΑΥΛΟΥ, ΔΗΜΗΤΡΙΟΣ ΣΕΡΠΑΝΟΣ'})
    books.insert({'_id':'14', 'title':'Διδασκαλία και μάθηση στη νοσηλευτική και άλλες επιστήμες υγείας', 'author':' Στέλλα Κοτζαμπασάκη'})
    books.insert({'_id':'21', 'title':'ΕΝΤΟΜΑ ΚΑΡΠΟΦΟΡΩΝ ΔΕΝΤΡΩΝ ΚΑΙ ΑΜΠΕΛΟΥ', 'author':' ΤΖΑΝΑΚΑΚΗΣ ΜΙΝΟΣ,ΚΑΤΣΟΓΙΑΝΝΟΣ ΒΥΡΩΝ'})
    books.insert({'_id':'25', 'title':'ΑΠΕΙΡΟΣΤΙΚΟΣ ΛΟΓΙΣΜΟΣ ΤΟΜΟΣ Ι', 'author':' FINNEY R.L., WEIR M.D., GIORDANO F.R.'})
    books.insert({'_id':'28', 'title':'Εισαγωγή στην Μικροοικονομική Ανάλυση', 'author':' Παντελής Παντελίδης'})
    books.insert({'_id':'30', 'title':'ΤΕΧΝΟΛΟΓΙΑ ΤΩΝ ΚΑΤΕΡΓΑΣΙΩΝ ΤΩΝ ΥΛΙΚΩΝ: ΜΗ ΣΥΜΒΑΤΙΚΕΣ ΚΑΤΕΡΓΑΣΙΕΣ', 'author':' Α. ΜΑΜΑΛΗΣ'})
except Exception as e:
    print('Unexpected error', type(e), e)

query = {'title': {'$regex': 'Εισαγωγ', '$options':'i'}} # είναι όπως το WHERE της SQL με βάση regular expression με επιλογή για case insensitive
projection = {'title':1, "_id": 0}
b = books.find(query, projection)
for x in b:
    print (x)


#
