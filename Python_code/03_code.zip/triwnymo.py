a=input('Δώσε a = ')
b=input('Δώσε b = ')
c=input('Δώσε c = ')

print('Λύνω την εξίσωση ', a,'x**2 +',b,'x +',c,'= 0')

a=int(a)
b=int(b)
c=int(c)

if a==0:
    if b==0:
        if c==0:
            print('Η εξίσωση είναι αόριστη.')
        else:
            print('Η εξίσωση είναι αδύνατη.')
    else:
        x=-c/b
        print('Η εξίσωση έχει μια λύση, x=',x)
else:
    diak=b*b-4*a*c
    print('Η διακρίνουσα είναι Δ=',diak)
    if diak<0:
        print('Η εξίσωση δεν έχει πραγματικές λύσεις.')
    if diak==0:
        print('Η εξίσωση έχει μια διπλή λύση.')
    r = diak**0.5
    x1=(-b-r)/(2*a)
    x2=(-b+r)/(2*a)
    print('x1=', x1)
    print('x2=', x2)

print('ΤΕΛΟΣ ΠΡΟΓΡΑΜΜΑΤΟΣ')

