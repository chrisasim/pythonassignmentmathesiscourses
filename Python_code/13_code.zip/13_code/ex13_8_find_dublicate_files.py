import os
import os.path


def main() :
    #define starting directory
    d = input("δώσε φάκελο: ")
    if not os.path.isdir(d): d = os.getcwd()
    print("start searching for {}".format(d))
    find_duplicates_in(d)

def find_duplicates_in(path) :
    # date_from_name = {}
    # for name in os.listdir(path):
    #     fullname = os.path.join(path, name)
    #     if os.path.isfile(fullname):
    #         date_from_name[fullname] = os.path.getmtime(fullname)

    data = {}
    path = path.encode(encoding='UTF-8')
    for root, dirs, files in os.walk(path):
        for filename in files:
            fullname = os.path.join(root, filename)
            #print(fullname)
            try:
                size = os.path.getsize(fullname)
                key = (size, filename)
                if key in data.keys():
                    data[key].append(fullname)
                else:
                    data[key] = [fullname]
            except :
                print('error in getting the size of file {}'.format(fullname,))

    for size, filename in sorted(data):
        names = data[(size, filename)]
        if len(names) > 1:
            f = os.path.split(filename)[1]
            print("{} ({} bytes) may be duplicated files....".format(filename, size))
            for name in names:
                n = os.path.split(name)[1]
                if n == f :
                    print("\t{0}".format(name))


if __name__ == '__main__':
    main()