import psutil
import platform
from datetime import datetime as dt
import time

print('Υπολογιστής με {} πυρήνες'.format(psutil.cpu_count()))
mem = psutil.virtual_memory().total/1024**3
print("Κεντρική Μνήμη = %0.2f GB" % mem)

print('Εκδοση λειτουργικού συστήματος: {}'.format(platform.platform()))
# print(platform.system())
# print(platform.release())
print('Χρησιμοποείται η Python έκδοση {}'.format(platform.python_version()))
print('Μεταγλωττιστής της Python: {}'.format(platform.python_compiler()))

def system_monitor():
    MiB = 1024**2
    cpu = psutil.cpu_times_percent()
    disk_root = psutil.disk_usage('/')
    phymem = psutil.virtual_memory()
    swap = psutil.swap_memory()
    doc = dict()

    doc['time'] = dt.now().time().strftime('%H:%M:%S')
    doc['disk_root'] = disk_root.free/MiB
    doc['phymem'] = phymem.free/MiB
    doc['swap'] = swap.total/MiB
    doc['cpu'] = {
        'user': cpu.user,
        'system': cpu.system,
        'idle': cpu.idle,
    }
    return doc

print ('System Monitor running....')
print ('time \t\t free disk \t free memory \t swap memory \t cpu user \t cpu system\t  cpu idle ')
while True:
    # Καταγραφή παραμέτρων συστήματος
    # TO DO : να δημιουργηθεί γραφικός σταθμός καταγραφής απόδοσης υπολογιστή
    m = system_monitor()
    print (m['time'],'\t %.2f' % m['disk_root'], '\t %.2f  \t\t %.2f\t' % (m['phymem'], m['swap']),
           '\t\t %5.1f %%' % m['cpu']['user'] ,
           '\t %5.1f %%' % m['cpu']['system'],
           '\t %5.1f %%' % m['cpu']['idle']
           )
    time.sleep(10)