# -*- coding: utf-8 -*-
import os
import os.path
import datetime
MIN_AGE = datetime.timedelta(days=5)

def main() :
    #define starting directory
    global MIN_AGE
    d = input("δώσε φάκελο: ")
    if not os.path.isdir(d): d = os.getcwd()
    min_age = input("days old :")
    try:
        MIN_AGE = datetime.timedelta(days=int(min_age))
    except:
        print("error in inserting number of ages")
    print("start searching for {}".format(d))
    find_recent_files(d)

def find_recent_files(path):
    recent_file = {}
    to_date = datetime.datetime.today().date()
    path = path.encode(encoding='UTF-8') # byte encoding to be passed to walk
    for root, dirs, files in os.walk(path):
        for filename in files:
            fullname = os.path.join(root, filename)
            try:
                file_time = os.path.getmtime(fullname)
                file_date = datetime.datetime.fromtimestamp(file_time).date()
                #print(fullname, file_date)
                file_age = (to_date - file_date)
                #print(file_age)
                if file_age <= MIN_AGE :
                    if file_age in recent_file.keys():
                        recent_file[file_age].append(fullname)
                    else:
                        recent_file[file_age] = [fullname]
            except :
                print('error in getting the modification time of file {}'.format(fullname,))
    for age in sorted(recent_file):
        names = recent_file[age]
        age = age.days
        if age == 0:
            print("todays' files are: ")
        else:
            print("files of {} days old are: ".format(age,))
        for f in names:
            #f = str.encode(f)
            #print ("\t\t", f.encode("utf-8", "surrogateescape"))
            print("\t\t", f)

if __name__ == '__main__':
    main()