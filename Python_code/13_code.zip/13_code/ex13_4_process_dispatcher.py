# -*- coding: utf-8 -*-
# Το πρόγραμμα αυτό εξομοιώνει τη λειτουργία του αλγόριθμου χρονοπρογραμματισμού Round Robin (RR)
# περιγράφει τις μεταγωγές περιβάλλοντος, για πόσο χρόνο θα εκτελείται η κάθε D, τον μέσο χρόνο αναμονής και απόκρισης.
mess = "\t\tEκτιμώμενος χρόνος (cpu burst time) σε ms :"
mess1="\t\tXρονική στιγμή ετοιμότητας σε ms ( >= 0):"
#symbols
NO = '~' # σύμβολο για κατάσταση εισόδου
W = '?' # σύμβολο για αναμονή (κατάσταση ετοιμότητας)
R = 'R' # σύμβολο για κατάσταση εκτέλεσης
M = '*' # σύμβολο για κατάσταση μεταγωγής

class Diergasia():
    def __init__(self, name, cpu, ready):
        self.name = name
        self.cpu = cpu
        self.ready = ready
        self.remain = cpu
        self.life =[]
        self.end = False
        # for x in range(0,self.ready): # η διεργασία δεν υπάρχει πριν τη χρονική στιγμή ready
        #     self.life.append ( NO )

    def new_state(self, state):
        self.life.append(state)
        if state == R : self.remain -= 1
        if self.remain == 0 :
            self.end = True

    def waiting_time(self):
        waiting = 0
        for x in self.life:
            if x == W : waiting += 1
        return waiting

    def response_time(self):
        response = 0
        for x in self.life:
            if x == W or x == M or x == R: response += 1
        if self.life[-1] == M : response -= 1
        return response

    def __str__(self):
        out=''
        for x in self.life:
            out+=x+'__'
        return self.name+'\t'+out

class Waiting_Processes:
    def __init__(self):
        self.items = []

    def insert(self, item):
        self.items.insert(0,item)

    def pop(self):
        return self.items.pop()

    def queue(self):
        return self.items

class OS_Scheduler(Diergasia, Waiting_Processes):
    def __init__(self, quantum, switching, process_list):
        self.quantum = quantum
        self.quantum_left = quantum
        self.switching = switching
        self.switching_left = switching
        self.cpu_process = None
        self.waiting_processes = Waiting_Processes()
        self.switching_processes = []
        self.clock = -1
        self.process_list = process_list

    def do_context_switch(self, p_list):
        p = len(p_list)
        #print('context switch between:', p_list)
        if p ==1 :
            self.cpu_process = p_list[0]
        else:
            if p_list[0] and not p_list[0].end:
                self.waiting_processes.insert(p_list[0])
            if p_list[1]:
                self.cpu_process = p_list[1]
        self.quantum_left = self.quantum
        self.switching_processes = []

    def start_context_switch(self, p1, p2):
        self.switching_processes = []
        self.switching_processes.extend([p1,p2])
        # print("Context switch : ", end ='')
        # self.switching_left = self.switching
        # for x in self.switching_processes:
        #     print(x.name, ", ", end='')

    def define_new_state(self):
        self.clock += 1
        for p in self.process_list:
            if self.clock < p.ready:  # η διεργασία όχι στον κύκλο χρονοπρογραμματισμού
                p.life.append(NO)
            elif self.clock == p.ready:  # η διεργασία μπαίνει στον κύκλο προγραμματισμού
                self.waiting_processes.insert(p)
                if len(self.switching_processes) == 0 and not self.cpu_process:
                    self.switching_processes.append(p)
                    self.waiting_processes.pop()
                    if self.switching == 0:
                        self.do_context_switch([self.cpu_process, p])
                        # η διεργασία είναι σε εκτέλεση
            if p == self.cpu_process:
                if p.end or self.quantum_left == 0:  # τερμάτισε ή τέλος κβάντου χρόνου
                    if len(self.waiting_processes.queue()) > 0:
                        if self.switching == 0:
                            self.do_context_switch([self.cpu_process, self.waiting_processes.pop()])
                        else:
                            self.cpu_process = None
                            self.start_context_switch(p, self.waiting_processes.pop())
                            self.switching_left = self.switching
                    elif not p.end:  # αν δεν έχει τερματίσει, έχει τελειώσει το κβάντο
                        self.quantum_left = self.quantum  # ανανέωση κβάντου χρονου
        # εαν εκετελείται διεργασία μειώνεται κατά 1 το κβάντο χρόνου
        if len(self.switching_processes) > 0:  # μεταγωγή
            if self.switching_left <= 0:
                self.do_context_switch(self.switching_processes)
            self.switching_left -= 1
        if self.cpu_process:
            self.quantum_left -= 1
        # ανανεώνουμε την κατάσταση σε όλες τις μη ολοκληρωμένες εργασίες
        if self.cpu_process and not self.cpu_process.end:
            self.cpu_process.new_state(R)
        for p in self.waiting_processes.queue():
            p.new_state(W)
        for p in self.switching_processes:
            p.new_state(M)

def insert_integer (message,minim):
    '''η συνάρτηση χρησιμοποιείται για να εισάγει δεδομένα ο χρήστης,
    ελέγχοντας την τιμή τους minim=0 για τιμές >= 0  και minim=1 για τιμές > 0
    '''
    while True:
        try:
            value_in = int(input(message))
            if minim == 0 and value_in >= 0 or minim == 1 and value_in > 0 : break
        except:
            print(message)
    return value_in

def define_processes():
    d_list =[]
    dierg = insert_integer("Eισάγετε τον αριθμό των διεργασιών που θα εκτελεστούν: ", 1)
    # αρχικοποιούμε τη λίστα των διεργασιών
    for i in range(0, dierg):  # ξεκινάει ένας βρόγχος με αριθμό επαναλήψεων τόσο όσες διεργασίες έδωσε ο χρήστης
        print("Dιεργασια  D%d." % (i + 1))
        cpu = insert_integer(mess,1)  # εισαγωγή cpu burst time , ο χρόνος είναι μόνο θετικός
        ready = insert_integer(mess1,0)  # εισάγουμε το χρόνος ετοιμότητας , ο χρόνος είναι θετικός ή μηδέν
        d = Diergasia('D%d'%(i+1), cpu, ready)
        d_list.append(d)
    return d_list

def active_processes(d_list):
    # έλεγχος αν υπάρχουν ακόμη διεργασίες με end = False
    for d in d_list:
        if not d.end : return True
    return False

def main():
    d_list = define_processes() # όρισε χαρακτηριστικά διεργασιών
    # όρισε χαρακτηριστικά αλγορίθμου χρονοπρογραμματισμού
    quantum =  insert_integer('Δώστε το κβάντο χρόνου σε ms (τιμές >0) : ', 1)
    switching = insert_integer('Δώστε το χρόνο μεταγωγής σε ms (τιμές >= 0) : ', 0)
    os_scheduler = OS_Scheduler(quantum, switching, d_list)
    while True:
        os_scheduler.define_new_state()
        if not active_processes(d_list): break
    max_time = 0
    char1 = '_'
    char2 = '__'
    for x in d_list:
        if len(x.life)> max_time: max_time = len(x.life)
    print ('Dx\t', end = '')
    for i in range(max_time):
        ch = char1 if i>9 else char2
        print(str(i)+ch, end='')
    print()
    for x in d_list:
        print (x)
    # υπολογισμός μέσου χρόνου αναμονής
    waiting = 0
    for x in d_list: waiting += x.waiting_time()
    waiting =  waiting/len(d_list)
    print ("Μέσος χρόνος αναμονής = %.2f" % waiting)
    # υπολογισμός μέσου χρόνου απ´οκρισης
    response = 0
    for x in d_list: response += x.response_time()
    response = response/len(d_list)
    print("Μέσος χρόνος απόκρισης = %.2f" % response)

if __name__ == '__main__' :
    main()
