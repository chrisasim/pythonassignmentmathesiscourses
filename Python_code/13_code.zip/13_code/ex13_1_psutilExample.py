import os
import psutil
import time

def get_host_cpu_stats():
    print (psutil.cpu_times())
    print('number of CPUs = ', psutil.cpu_count())
    return {
        'kernel': int(psutil.cpu_times()[2]),
        'idle': int(psutil.cpu_times()[3]),
        'user': int(psutil.cpu_times()[0]),
        'iowait': int(psutil.cpu_times()[4]),
    }

def get_stats():
    proc = psutil.Process(os.getpid())
    profile = dict(
        # vm_cput = psutil.cpu_times(),  # dict
        vm_cpu=psutil.cpu_percent(),
        vm_mem=psutil.virtual_memory(),  # dict
        # swap = psutil.swap_memory(),
        # proc_cput = proc.get_cpu_times(),
        proc_cpu=proc.get_cpu_percent(),
        proc_mem=proc.get_memory_info(),
    )
    return profile

print(get_stats())

print(get_host_cpu_stats())

mem = psutil.virtual_memory().total/1024**3

print('Φυσική Μνήμη = %.2f Gbytes' % mem)
#The amount of total physical memory on the system, in bytes.

print('Number of CPUs=', psutil.NUM_CPUS)
#The number of CPUs on the system. This is preferable than using os.environ['NUMBER_OF_PROCESSORS'] as it is more accurate and always available.

Gib = 1024**3
d_io = psutil.disk_io_counters(perdisk=True)
for d in d_io:
    if 'sd' in d:
        r_count = d_io[d].read_count
        w_count = d_io[d].write_count
        w_gb = d_io[d].read_bytes/Gib
        r_gb = d_io[d].write_bytes/Gib
        print('%s : \t%d\t%d\t%.2f\t%.2f' % (d, r_count, w_count, r_gb, w_gb))

t1 = time.time()
t2 = psutil.boot_time()
seconds = int(t1-t2)
m, s = divmod(seconds, 60)
h, m = divmod(m, 60)
d, h = divmod(h, 24)
print ('Ο υπολογιστής είναι σε λειτουργία = %d μέρες και %d ώρες %02d min %02d sec' % (d, h, m, s))
print(os.name)

import platform
print(platform.platform())