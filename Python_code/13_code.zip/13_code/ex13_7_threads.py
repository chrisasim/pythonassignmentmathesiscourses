import threading
from queue import Queue
import time
# κλείδωμα για σειριακή πρόσβαση στην κονσόλα εξόδου
lock = threading.Lock()

def do_work(item):
    time.sleep(.1) # έστω ότι για 0.1 sec εκτελεί ένα έργο.
    # η εντολή print γίνεται με κλείδωμα για να μην ανακατευτούν οι εκτυπώσεις.
    with lock:
        print(threading.current_thread().name,item)
# η ελαφρά διεργασία worker παίρνει ένα αντικείμενο από την ουρά και το επεξεργάζεται
def worker():
    while True:
        item = q.get()
        do_work(item)
        q.task_done()
# δημιουργία ουράς q.
#main
q = Queue()
for i in range(5):
     t = threading.Thread(target=worker) # h ελαφρά διεργασία δημιουργείται
     t.daemon = True  # .
     t.start()
# stuff work items on the queue (in this case, just a number).
start = time.perf_counter()
for item in range(20):
    q.put(item)
q.join()       # block μέχρι να τελειώσουν όλες οι διεργασίες
print('time:',time.perf_counter() - start)
# σημείωση: πιθανόν ανάλογα με τον αριθμό πυρήνων του υπολογιστή και ανάλογα με τον 
# αριθμό ελαφρών διεργασιών να μειωθεί ο χρόνος από 0.1 * 10 = 1.0 sec σε κλάσμα αυτού του χρόνου
