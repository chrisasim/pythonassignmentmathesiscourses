import os
import psutil
import time

while True:

    for proc in psutil.process_iter():
        try:
            pinfo = proc.as_dict(attrs=['pid', 'name', 'cpu_percent', 'memory_info'])
        except psutil.NoSuchProcess:
            pass
        else:
            if pinfo['cpu_percent']> 0.1 :
                print(pinfo['pid'], '\t', pinfo['cpu_percent'], '\t', pinfo['memory_info'][0], '\t', pinfo['name'] )
    time.sleep(10)
    print ('\nΚατάλογος διεργασιών με CPU % > 0.1')
    print ('PID\tCPU % \tMemory info\t name')
    cpu_times = psutil.cpu_times()