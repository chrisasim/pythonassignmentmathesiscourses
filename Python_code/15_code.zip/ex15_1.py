# -*- coding: utf-8 -*-
import smtplib
import datetime

def send_email(user, recipient, sub, body):
    body = body+'\n email sent time {}'.format(datetime.datetime.now())
    #body = body.encode('ascii')
    #recipient = recipient+' <'+recipient+'>'
    pwd = input('δώσε password :')
    frm = user+"@upatras.gr"
    #frm = frm+' <'+frm+'>'
    #subject = 'Subject: '+ sub
    subject = sub
    server = smtplib.SMTP_SSL("mail.upatras.gr", 465)
    server.ehlo()
    # server.starttls()
    print(server.login(user, pwd))
    server.sendmail(frm, recipient, subject, body)
    server.quit()

send_email('avouris', 'navouris@gmail.com', 'hi there', 'this is a silly message')