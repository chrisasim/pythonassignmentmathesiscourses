# server.py


def modInput(inputStr):
    """
    Απλή συνάρτηση μετατροπής των δεδομένων που αποστέλει
    ο χρήστης. Θα μετατρέπει σε κεφαλαίο το πρώτο γράμμα κάθε λέξης
    """

    print("Processing input ...")
    return inputStr.title()

def client_thread(conn, ip, port, MAX_BUFFER_SIZE = 4096):

    # τα δεδομένα στέλνονται σε bytes
    # καθορίζουμε το μέγιστο αριθμό bytes που στέλνονται κάθε φορά
    bytesFromClient = conn.recv(MAX_BUFFER_SIZE)

    # αποκωδικοποιούμε τα δεδομένα και αφαιρούμε το τέλος γραμμής (end of line)
    clientInput = bytesFromClient.decode("utf8").rstrip()

    # τροποποιούμε τα δεδομένα από τους πελάτες
    result = modInput(clientInput)
    print("Και το αποτέλεσμα του  {} είναι: {}".format(clientInput, result))

    modStr = result.encode("utf8")  # κωδικοποιούμε το αποτέλεσμα
    conn.sendall(modStr)  # το στέλνουμε στον πελάτη
    conn.close()  # κλείνουμε τη σύνδεση
    print('Η σύνδεση  ' + ip + ':' + port + " έκλεισε")

def start_server():

    import socket
    recvSoc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # για να ξεκινά καινα τερματίζει εύκολα η εφαρμογή
    recvSoc.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    print('Δημιουργία σύνδεσης')

    socNum = 10000
    hostName = "127.0.0.1"  # χρησιμοποιούμε την ip διεύθυνση του localhost
    try:
        recvSoc.bind((hostName, socNum))
        print('Η σύνδεση ολοκληρώθηκε')

    except socket.error as msg:
        import sys
        print('Αποτυχία σύνδεσης. Παρουσιάστηκε σφάλμα: ' + str(sys.exc_info()))
        sys.exit()

    #Ξεκινά η αναμονή αποστολής δεδομένων
    recvSoc.listen(10)
    print('Αναμονή για σύνδεση ... ')

    #  χρησιμοποιούμε την Thread για να εκτελούμε παράλληλες διεργασίες
    from threading import Thread

    # Ο εξυπηρετητής θα είναι σε βρόχο αναμονής αιτημάτων
    while True:
        conn, clientAddr = recvSoc.accept()
        ip, port = str(clientAddr[0]), str(clientAddr[1])
        print('Δέχτηκα αίτημα από  ' + ip + ':' + port)
        try:
            Thread(target=client_thread, args=(conn, ip, port)).start()
        except:
            print("Αδυναμία σύνδεσης!")
            import traceback
            traceback.print_exc()
    recvSoc.close()

start_server()