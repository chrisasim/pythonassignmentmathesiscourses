from socket import *
serverPort = 10000
serverSocket = socket(AF_INET, SOCK_STREAM)
# Δημιουργεί μια αρχική υποδοχή
serverSocket.bind(('', serverPort))
#Συσχετίζεται ο αριθμός θύρας serverPort με αυτήν την υποδοχή
serverSocket.listen(1)
# Η serverSocket είναι η αρχική υποδοχή. Αναμένει για κάποιο
# εισερχόμενο αίτημα TCP. Η παράμετρος 1 καθορίζει τον μέγιστο
# αριθμό συνδέσεων σε αναμονή.

print('The server is ready to receive')
while 1:
    connectionSocket, addr = serverSocket.accept()
# Όταν έλθει κάποιο αίτημα, η μέθοδος accept() δημιουργεί μια νέα
# υποδοχή (connectionSocket). Θα την χρησιμοποιήσει αποκλειστικά #γι’ αυτόν τον πελάτη.
# Κατόπιν ολοκληρώνεται η χειραψία και εγκαθιδρύεται η σύνδεση TCP μεταξύ connectionSocket και #clientSocket.
    sentence = connectionSocket.recv(1024)
#Διαβάζει τα δεδομένα τα byte που στέλνονται από την υποδοχή #(αλλά όχι τη διεύθυνση, όπως στο UDP)
    capitalizedSentence = sentence.upper()
    connectionSocket.send(capitalizedSentence)
    connectionSocket.close()
#Κλείνει την υποδοχή σύνδεσης για αυτόν τον πελάτη. Εφόσον η αρχική υποδοχή (serverSocket) παραμένει ανοιχτή,
# μπορεί να δεχθεί #αίτημα από άλλον πελάτη.

