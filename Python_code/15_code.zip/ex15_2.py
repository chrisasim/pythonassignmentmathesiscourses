import smtplib
import datetime
# Import the email modules we'll need
from email.mime.text import MIMEText

def send_email(user, recipient, sub, textfile):
    with open(textfile) as fp:
        # Create a text/plain message
        t = fp.read()
        t = t + '\n email sent time {}'.format(datetime.datetime.now())
        msg = MIMEText(fp.read())

    msg['Subject'] = 'The contents of %s' % textfile
    msg['From'] = user+"@upatras.gr"
    msg['To'] = recipient
    pwd = input('δώσε password :')
    server = smtplib.SMTP_SSL("mail.upatras.gr", 465)
    server.ehlo()
    # server.starttls()
    print(server.login(user, pwd))
    server.send_message(msg)
    #server.sendmail(frm, recipient, subject, body)
    server.quit()

send_email('avouris', 'navouris@gmail.com', 'hi there', 'ex15_1.py')



    # Open a plain text file for reading.  For this example, assume that
    # the text file contains only ASCII characters.


    # me == the sender's email address
    # you == the recipient's email address


    # Send the message via our own SMTP server.
    # s = smtplib.SMTP('localhost')
    # s.send_message(msg)
    # s.quit()