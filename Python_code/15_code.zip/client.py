# client.py


import socket

comSoc = socket.socket(socket.AF_INET, socket.SOCK_STREAM) # UDP επικοινωνία
socNum = 10000
hostName = "127.0.0.1" # χρησιμοποιούμε την ip διεύθυνση του localhost
comSoc.connect((hostName, socNum))

inputStr = input("Δώστε το κείμενο, όλα τα γράμματα πεζά:\n")
comSoc.send(inputStr.encode("utf8"))   # Η μέθοδος send της βιβλιοθήκης δέχεται ως όρισμα bytes,
                                    # άρα κωδικοποιούμε την είσοδο πριν την στείλουμε

resultInBytes = comSoc.recv(4096) # καθορίζουμε το μέγιστο μέγεθος σε bytes που μπορούν να ληφθούν κάθε φορά
result_string = resultInBytes.decode("utf8") # και η μέθοδος receive επιστρέφει bytes, άρα πρέπει να αποκωδικοποιήσουμε
                                             # το αποτέλεσμα


print("Το αποτέλεσμα της επεξεργασίας είναι: {}".format(result_string))