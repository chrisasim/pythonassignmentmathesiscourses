# TCPclient.py
from socket import * 
serverName = '127.0.0.1'
serverPort = 10000 
clientSocket = socket(AF_INET, SOCK_STREAM) 
# Δημιουργείται υποδοχή πελάτη 
clientSocket.connect((serverName,serverPort)) 
# Ξεκινά η σύνδεση μεταξύ πελάτη και εξυπηρετητή,  
# πραγματοποιείται η χειραψία και εγκαθίσταται η σύνδεση TCP.

sentence = input('input lowercase sentence:') 
#Θέτει στη μεταβλητή “sentence” τη συμβολοσειρά που πληκτρολογεί
#ο χρήστης.
clientSocket.send(sentence.encode('utf-8'))
# Στέλνει τη συμβολοσειρά “sentence” μέσω της υποδοχής του πελάτη
# στη σύνδεση TCP. Δεν χρειάζεται να δοθούν στοιχεία του
# εξυπηρετητή. Ο πελάτης περιμένει τώρα απάντηση.

modifiedSentence = clientSocket.recv(1024) 
#Η απάντηση δίνεται ως τιμή στην «modifiedSentence”
print('From Server: ', modifiedSentence)

#Μετά την εκτύπωση των κεφαλαίων, κλείνουμε την υποδοχή πελάτη
clientSocket.close()
