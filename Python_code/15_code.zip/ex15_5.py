# -*- coding: utf-8 -*-
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import datetime

def send_email(user, server):
    # ορισμός παραλήπτη:
    rec = input("Ορισμός παραλήπτη ή παραληπτών (χωρισμένων με κόμματα)...")
    recipients =rec.split(',')
    print('ΠΕΡΙΕΧΟΜΕΝΟ ΜΗΝΥΜΑΤΟΣ:')
    subj =input('SUBJECT:')
    body = input('BODY:\n')
    body = body + "\n Η ώρα που στέλνεται το μήνυμα αυτό είναι η " + \
           "{}".format(datetime.datetime.now())
    msg = MIMEMultipart()
    frm = user+"@upatras.gr"
    msg['Subject'] = subj
    msg['Body'] = body
    my_attachment = MIMEText(body.encode('utf-8'), _charset='utf-8')
    msg.attach(my_attachment)
    for recipient in recipients:
        to = recipient
        try:
            msg['To'] = to
            print(server.sendmail(frm, to, msg.as_string()))
        except:
            print('error in sending message')
    server.quit()

def main():
    # ορισμός αποστολέα και παραλήπτη
    go_ahead = False
    print('Αποστολή μηνύματος από χρήστη του mail.upatras.gr')
    print('Δώστε user name και password λογαριασμού αποστολέα:')
    user = input('user name:')
    passw = input('password:')
    # σύνδεση και login στον εξυπηρετητή mail.upatras.gr
    try:
        server = smtplib.SMTP_SSL("mail.upatras.gr", 465)
        print(server.ehlo())
        print(server.login(user, passw))
        go_ahead = True
    except:
        print('Σφάλμα σύνδεσης στον εξυπηρετητή mail.upatras.gr')
    if go_ahead: send_email(user, server)

main()